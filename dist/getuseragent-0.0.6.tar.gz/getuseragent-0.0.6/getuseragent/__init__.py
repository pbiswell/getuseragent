from getuseragent.getuseragent import UserAgent
from getuseragent.retrieve import GetList
