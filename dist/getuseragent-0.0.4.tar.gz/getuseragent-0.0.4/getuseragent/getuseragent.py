"""
Name: GetUserAgents
Author: Paul Biswell
Version: 0.0.4
Link: https://github.com/pbiswell/getuseragents
"""
#from getuseragent import retrieve
import random
import getuseragent.retrieve
#from getuseragent import UserAgent

version = "0.0.4"

class UserAgent:
    def __init__(self, ua="all", limit=0, total=0, requestsPrefix=False):
        self.ua = ua
        self.limit = limit
        self.total = total
        self.requestsPrefix = requestsPrefix
        self.list = []
        self.version = version
        self.Setup()

    def Format(self, ua):
        """ Returns formatted user agent for requests handler if specified. """
        if self.requestsPrefix == True:
            ua = {"User-Agent": ua}
        return ua
        
    def Setup(self):
        """ Creates user agent list based on your choices. Default is all user agents except bots. """
        if self.ua:
            self.list = retrieve.GetList(self.ua.split('+'), limit=self.limit)
        else:
            self.list = retrieve.GetList(limit=self.limit)
        
        if self.total > 0:
            random.shuffle(self.list)
            self.list = self.list[0:self.total]
            
    def Random(self):
        """ Returns random user agent based on your chosen settings """
        return self.Format(random.choice(self.list))